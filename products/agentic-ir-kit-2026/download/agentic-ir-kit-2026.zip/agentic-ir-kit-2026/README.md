# Agentic AI Incident Response Kit 2026

A production-ready starter kit for teams operating AI agents, tool-using assistants, browser automations, and multi-step LLM workflows.

## What you get

- Failure triage playbook for tool, model, memory, network, browser, and orchestration failures
- Incident severity model and first-15-minute response checklist
- Reusable postmortem and regression templates
- A compact JSON observability schema
- A Python failure classifier for normalizing raw agent errors
- A cost-of-delay calculator for prioritizing revenue-impacting incidents
- Deployment/runbook checklist for safer hotfixes and blue-green recovery
- Prompt templates for incident commander, investigator, verifier, and business-impact owner

## Who it is for

Engineering teams shipping agentic AI systems who need something more operational than generic LLM monitoring advice.

## Quick start

1. Copy `templates/incident_intake.md` into your incident tracker.
2. Normalize raw failures with `tools/classify_failure.py`.
3. Use `templates/first_15_minutes.md` during an incident.
4. Record evidence using `observability_schema.json`.
5. Close with `templates/postmortem.md` and one recurrence-prevention action.

## License

Commercial use is allowed for one organization. Redistribution or resale of this kit is not allowed. See `LICENSE.txt`.
