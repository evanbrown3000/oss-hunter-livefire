# Incident Intake

**Incident ID:**
**Started:**
**Owner:**
**Severity:**
**User-visible symptom:**
**Affected workflow:**
**Estimated business impact:**
**Last known good:**
**Failure class:**
**Primary evidence:**
**Independent evidence:**
**Current hypothesis:**
**Disconfirming evidence:**
**Next reversible action:**
**Acceptance condition:**
