# Postmortem

## Impact
What customers or revenue workflows were affected? Quantify where possible.

## Timeline
List only decision-changing events.

## Root cause
Trigger -> failing mechanism -> propagation -> visible symptom.

## Why detection/recovery failed
What should have noticed or recovered, and why did it not?

## Fix
What changed in the live system?

## Validation
What fresh user-visible evidence proves recovery?

## Recurrence prevention
One concrete change that reduces recurrence probability or time-to-recovery.

## What not to repeat
Record failed approaches that should not be retried without a materially different hypothesis.
