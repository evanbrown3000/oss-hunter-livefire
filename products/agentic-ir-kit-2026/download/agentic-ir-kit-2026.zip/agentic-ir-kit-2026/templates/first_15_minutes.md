# First 15 Minutes Checklist

- [ ] Write the exact user-visible symptom in one sentence.
- [ ] Mark the affected revenue/customer workflow.
- [ ] Assign SEV level.
- [ ] Record last known-good time/version.
- [ ] Capture one primary user-visible artifact.
- [ ] Capture one independent machine artifact.
- [ ] Identify whether the failure is model/tool/browser/memory/orchestration/infra/economic.
- [ ] Check for blast radius: one run, one tenant, one account, or global.
- [ ] Stop only the smallest harmful component if needed.
- [ ] Choose a reversible repair path.
- [ ] Define the acceptance test before changing code/config.
