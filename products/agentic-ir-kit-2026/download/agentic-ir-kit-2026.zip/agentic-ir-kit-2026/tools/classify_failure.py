#!/usr/bin/env python3
import re, sys
RULES = {
    "BROWSER": [r"selector", r"element not found", r"navigation", r"captcha", r"too many requests", r"page.*closed"],
    "TOOL": [r"schema", r"tool.*timeout", r"permission", r"connector", r"invalid argument"],
    "MEMORY": [r"stale", r"contradict", r"retriev", r"context.*missing", r"handoff"],
    "ORCHESTRATION": [r"deadlock", r"duplicate", r"queue", r"fanout", r"leader", r"worker.*stuck"],
    "INFRA": [r"out of memory", r"oom", r"disk", r"cpu", r"connection refused", r"service.*failed"],
    "MODEL": [r"hallucin", r"refusal", r"malformed", r"context length", r"invalid json"],
    "ECONOMIC": [r"negative margin", r"cost.*revenue", r"unprofitable", r"fee.*exceed"]
}
text = " ".join(sys.argv[1:]) if len(sys.argv) > 1 else sys.stdin.read()
hits=[]
for cls, pats in RULES.items():
    score=sum(bool(re.search(p, text, re.I)) for p in pats)
    if score: hits.append((score, cls))
print(max(hits)[1] if hits else "UNKNOWN")
