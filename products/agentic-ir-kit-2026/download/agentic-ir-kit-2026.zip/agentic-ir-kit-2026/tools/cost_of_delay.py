#!/usr/bin/env python3
import argparse
p=argparse.ArgumentParser()
p.add_argument('--revenue-per-hour', type=float, required=True)
p.add_argument('--blocked-fraction', type=float, default=1.0)
p.add_argument('--hours', type=float, required=True)
a=p.parse_args()
loss=a.revenue_per_hour*a.blocked_fraction*a.hours
print(f"estimated_cost_of_delay_usd={loss:.2f}")
