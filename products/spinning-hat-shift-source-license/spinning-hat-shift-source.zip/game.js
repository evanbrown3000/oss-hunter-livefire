(() => {
  "use strict";

  const canvas = document.getElementById("game");
  const ctx = canvas.getContext("2d", { alpha: false });
  const overlay = document.getElementById("overlay");
  const overlayTitle = document.getElementById("overlay-title");
  const overlayCopy = document.getElementById("overlay-copy");
  const primary = document.getElementById("primary");
  const scoreEl = document.getElementById("score");
  const comboEl = document.getElementById("combo");
  const bestEl = document.getElementById("best");
  const dashLabel = document.getElementById("dash-meter-label");
  const toastEl = document.getElementById("toast");

  const W = canvas.width;
  const H = canvas.height;
  const TAU = Math.PI * 2;
  const preview = new URLSearchParams(location.search).get("preview") === "1";
  let seed = preview ? 914173 : (Date.now() ^ (Math.random() * 0xffffffff)) >>> 0;
  const random = () => {
    seed = (seed * 1664525 + 1013904223) >>> 0;
    return seed / 4294967296;
  };

  const state = {
    mode: "menu",
    time: 0,
    level: 1,
    score: 0,
    combo: 1,
    comboClock: 0,
    lives: 3,
    spawnClock: 0,
    flash: 0,
    shake: 0,
    best: Number(localStorage.getItem("spinning-hat-shift-best") || 0),
    audio: null,
    muted: false,
    pointerX: null,
  };

  const keys = { left: false, right: false };
  const player = {
    x: W / 2,
    y: H - 92,
    vx: 0,
    angle: 0,
    radius: 28,
    dash: 1,
    dashTimer: 0,
    invuln: 0,
    shield: 0,
  };

  const objects = [];
  const particles = [];
  const clouds = Array.from({ length: 10 }, (_, i) => ({
    x: random() * W,
    y: random() * H,
    speed: 4 + random() * 12,
    size: 45 + random() * 95,
    alpha: .025 + random() * .06,
    phase: i,
  }));

  bestEl.textContent = String(state.best);

  function initAudio() {
    if (state.audio || state.muted) return;
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext) return;
    state.audio = new AudioContext();
  }

  function sound(freq, duration = .08, type = "sine", gain = .035, slide = 0) {
    initAudio();
    const ac = state.audio;
    if (!ac) return;
    if (ac.state === "suspended") ac.resume().catch(() => {});
    const osc = ac.createOscillator();
    const amp = ac.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, ac.currentTime);
    if (slide) osc.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), ac.currentTime + duration);
    amp.gain.setValueAtTime(gain, ac.currentTime);
    amp.gain.exponentialRampToValueAtTime(.0001, ac.currentTime + duration);
    osc.connect(amp).connect(ac.destination);
    osc.start();
    osc.stop(ac.currentTime + duration);
  }

  function reset() {
    state.mode = "running";
    state.time = 0;
    state.level = 1;
    state.score = 0;
    state.combo = 1;
    state.comboClock = 0;
    state.lives = 3;
    state.spawnClock = 0;
    state.flash = 0;
    state.shake = 0;
    objects.length = 0;
    particles.length = 0;
    Object.assign(player, { x: W / 2, y: H - 92, vx: 0, angle: 0, dash: 1, dashTimer: 0, invuln: 0, shield: 0 });
    overlay.classList.remove("visible");
    canvas.focus({ preventScroll: true });
    updateHud();
    sound(220, .12, "triangle", .04, 280);
  }

  function gameOver() {
    state.mode = "gameover";
    state.best = Math.max(state.best, Math.floor(state.score));
    localStorage.setItem("spinning-hat-shift-best", String(state.best));
    bestEl.textContent = String(state.best);
    overlayTitle.textContent = "Shift complete";
    overlayCopy.innerHTML = `You banked <strong>${Math.floor(state.score)}</strong> points and reached shift ${state.level}. Your best is <strong>${state.best}</strong>.`;
    primary.textContent = "Spin again";
    overlay.classList.add("visible");
    sound(170, .5, "sawtooth", .035, -100);
  }

  function pause() {
    if (state.mode === "running") {
      state.mode = "paused";
      overlayTitle.textContent = "Paused";
      overlayCopy.textContent = "The storm is holding its breath.";
      primary.textContent = "Resume";
      overlay.classList.add("visible");
    } else if (state.mode === "paused") {
      state.mode = "running";
      overlay.classList.remove("visible");
      canvas.focus({ preventScroll: true });
    }
  }

  function toast(text) {
    toastEl.textContent = text;
    toastEl.classList.add("show");
    clearTimeout(toast.timer);
    toast.timer = setTimeout(() => toastEl.classList.remove("show"), 900);
  }

  function updateHud() {
    scoreEl.textContent = String(Math.floor(state.score));
    comboEl.textContent = `×${state.combo}`;
    dashLabel.textContent = player.dash >= .999 ? "Dash ready" : `Dash ${Math.round(player.dash * 100)}%`;
  }

  function emit(x, y, color, count = 8, speed = 130) {
    for (let i = 0; i < count; i++) {
      const a = random() * TAU;
      const s = speed * (.35 + random());
      particles.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life: .35 + random() * .55, max: .9, size: 2 + random() * 4, color });
    }
  }

  function spawn() {
    const level = state.level;
    const r = random();
    let type = "ticket";
    if (r > .72 && r <= .91) type = "gust";
    else if (r > .91 && r <= .975) type = "star";
    else if (r > .975) type = random() > .5 ? "shield" : "clock";
    const radius = type === "gust" ? 27 : type === "ticket" ? 18 : 15;
    objects.push({
      type,
      x: 55 + random() * (W - 110),
      y: -40,
      vx: type === "gust" ? (random() - .5) * (80 + level * 8) : (random() - .5) * 30,
      vy: 105 + level * 11 + random() * 48,
      radius,
      angle: random() * TAU,
      spin: (random() - .5) * 5,
      phase: random() * TAU,
      value: type === "ticket" ? 25 : type === "star" ? 80 : 0,
    });
  }

  function dash() {
    if (state.mode !== "running" || player.dash < .999) return;
    player.dash = 0;
    player.dashTimer = .34;
    state.shake = 5;
    emit(player.x, player.y + 10, "#71e8ff", 22, 230);
    sound(180, .18, "sawtooth", .045, 650);
  }

  function hit(o) {
    if (player.invuln > 0 || player.dashTimer > 0) {
      if (player.dashTimer > 0 && o.type === "gust") {
        state.score += 40 * state.combo;
        state.combo = Math.min(9, state.combo + 1);
        emit(o.x, o.y, "#ff7e90", 18, 200);
        sound(120, .09, "square", .025, 250);
        return true;
      }
      return false;
    }
    if (player.shield > 0) {
      player.shield = 0;
      player.invuln = .6;
      emit(o.x, o.y, "#aa83ff", 20, 220);
      toast("Shield saved the shift");
      sound(380, .18, "triangle", .04, -140);
      return true;
    }
    state.lives--;
    state.combo = 1;
    state.comboClock = 0;
    player.invuln = 1.15;
    state.flash = .28;
    state.shake = 12;
    emit(o.x, o.y, "#ff667d", 28, 260);
    sound(95, .26, "sawtooth", .055, -40);
    if (state.lives <= 0) gameOver();
    return true;
  }

  function collect(o) {
    if (o.type === "ticket" || o.type === "star") {
      state.score += o.value * state.combo;
      state.combo = Math.min(9, state.combo + 1);
      state.comboClock = 3.1;
      player.dash = Math.min(1, player.dash + (o.type === "star" ? .34 : .12));
      const color = o.type === "star" ? "#71e8ff" : "#ffd166";
      emit(o.x, o.y, color, o.type === "star" ? 18 : 10, 160);
      sound(o.type === "star" ? 720 : 480 + state.combo * 22, .09, "sine", .035, 100);
      return true;
    }
    if (o.type === "shield") {
      player.shield = 1;
      toast("Shield online");
      emit(o.x, o.y, "#aa83ff", 18, 160);
      sound(330, .2, "triangle", .035, 320);
      return true;
    }
    if (o.type === "clock") {
      for (const item of objects) item.vy *= .72;
      toast("Storm slowed");
      emit(o.x, o.y, "#7df2c4", 18, 160);
      sound(520, .22, "sine", .035, -210);
      return true;
    }
    return false;
  }

  function update(dt) {
    for (const cloud of clouds) {
      cloud.y += cloud.speed * dt;
      if (cloud.y > H + cloud.size) { cloud.y = -cloud.size; cloud.x = random() * W; }
    }
    for (let i = particles.length - 1; i >= 0; i--) {
      const p = particles[i];
      p.life -= dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vx *= Math.pow(.16, dt);
      p.vy = p.vy * Math.pow(.25, dt) + 100 * dt;
      if (p.life <= 0) particles.splice(i, 1);
    }
    if (state.mode !== "running") return;

    state.time += dt;
    state.level = 1 + Math.floor(state.time / 18);
    state.score += dt * (7 + state.level * 1.5);
    state.flash = Math.max(0, state.flash - dt);
    state.shake = Math.max(0, state.shake - dt * 28);
    player.invuln = Math.max(0, player.invuln - dt);
    player.dashTimer = Math.max(0, player.dashTimer - dt);
    player.dash = Math.min(1, player.dash + dt * .085);
    player.angle += dt * (5.2 + Math.abs(player.vx) / 90 + (player.dashTimer > 0 ? 13 : 0));
    if (state.comboClock > 0) {
      state.comboClock -= dt;
      if (state.comboClock <= 0) state.combo = 1;
    }

    let direction = (keys.right ? 1 : 0) - (keys.left ? 1 : 0);
    if (state.pointerX !== null) direction = Math.max(-1, Math.min(1, (state.pointerX - player.x) / 80));
    const accel = player.dashTimer > 0 ? 2050 : 1150;
    const maxSpeed = player.dashTimer > 0 ? 680 : 360;
    player.vx += direction * accel * dt;
    player.vx *= Math.pow(direction ? .24 : .045, dt);
    player.vx = Math.max(-maxSpeed, Math.min(maxSpeed, player.vx));
    player.x += player.vx * dt;
    const edge = 42;
    if (player.x < edge) { player.x = edge; player.vx *= -.25; }
    if (player.x > W - edge) { player.x = W - edge; player.vx *= -.25; }

    state.spawnClock -= dt;
    const spawnRate = Math.max(.24, .72 - state.level * .032);
    if (state.spawnClock <= 0) {
      spawn();
      state.spawnClock = spawnRate * (.65 + random() * .7);
      if (state.level > 3 && random() < .15) spawn();
    }

    for (let i = objects.length - 1; i >= 0; i--) {
      const o = objects[i];
      o.x += o.vx * dt + Math.sin(state.time * 2.1 + o.phase) * 12 * dt;
      o.y += o.vy * dt;
      o.angle += o.spin * dt;
      if (o.x < 25 || o.x > W - 25) o.vx *= -1;
      const dx = o.x - player.x;
      const dy = o.y - player.y;
      if (dx * dx + dy * dy < Math.pow(o.radius + player.radius * .82, 2)) {
        const consumed = o.type === "gust" ? hit(o) : collect(o);
        if (consumed) objects.splice(i, 1);
      } else if (o.y > H + 55) {
        if ((o.type === "ticket" || o.type === "star") && state.combo > 1) {
          state.combo = Math.max(1, state.combo - 1);
          state.comboClock = 1.5;
        }
        objects.splice(i, 1);
      }
    }
    updateHud();
  }

  function roundedRect(x, y, w, h, r) {
    ctx.beginPath();
    ctx.roundRect(x, y, w, h, r);
  }

  function drawBackground() {
    const g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, "#171b39");
    g.addColorStop(.45, "#131a35");
    g.addColorStop(1, "#0a1024");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);

    const glow = ctx.createRadialGradient(W * .5, H * .88, 10, W * .5, H * .88, 430);
    glow.addColorStop(0, "rgba(113,232,255,.14)");
    glow.addColorStop(.55, "rgba(170,131,255,.06)");
    glow.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = glow;
    ctx.fillRect(0, 0, W, H);

    for (const cloud of clouds) {
      ctx.save();
      ctx.globalAlpha = cloud.alpha;
      ctx.fillStyle = "#dbe6ff";
      ctx.beginPath();
      ctx.ellipse(cloud.x, cloud.y, cloud.size, cloud.size * .24, Math.sin(cloud.phase) * .08, 0, TAU);
      ctx.ellipse(cloud.x - cloud.size * .35, cloud.y - cloud.size * .08, cloud.size * .44, cloud.size * .25, 0, 0, TAU);
      ctx.ellipse(cloud.x + cloud.size * .25, cloud.y - cloud.size * .1, cloud.size * .5, cloud.size * .3, 0, 0, TAU);
      ctx.fill();
      ctx.restore();
    }

    ctx.strokeStyle = "rgba(255,255,255,.035)";
    ctx.lineWidth = 1;
    for (let x = 40; x < W; x += 80) {
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
    }
    for (let y = 40; y < H; y += 80) {
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
    }
  }

  function drawTicket(o) {
    ctx.save();
    ctx.translate(o.x, o.y);
    ctx.rotate(o.angle);
    ctx.shadowColor = "rgba(255,209,102,.7)";
    ctx.shadowBlur = 16;
    roundedRect(-17, -11, 34, 22, 5);
    const g = ctx.createLinearGradient(-17, 0, 17, 0);
    g.addColorStop(0, "#ffb456"); g.addColorStop(.5, "#ffe88a"); g.addColorStop(1, "#ffcb62");
    ctx.fillStyle = g; ctx.fill();
    ctx.shadowBlur = 0;
    ctx.strokeStyle = "rgba(101,56,10,.45)"; ctx.lineWidth = 2;
    ctx.setLineDash([3, 3]);
    ctx.beginPath(); ctx.moveTo(-7, -8); ctx.lineTo(-7, 8); ctx.stroke();
    ctx.setLineDash([]);
    ctx.fillStyle = "rgba(101,56,10,.65)"; ctx.font = "900 10px system-ui"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.fillText("★", 5, 0);
    ctx.restore();
  }

  function starPath(points, outer, inner) {
    ctx.beginPath();
    for (let i = 0; i < points * 2; i++) {
      const r = i % 2 ? inner : outer;
      const a = -Math.PI / 2 + i * Math.PI / points;
      const x = Math.cos(a) * r, y = Math.sin(a) * r;
      if (!i) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    ctx.closePath();
  }

  function drawStar(o, color = "#71e8ff") {
    ctx.save(); ctx.translate(o.x, o.y); ctx.rotate(o.angle);
    ctx.shadowColor = color; ctx.shadowBlur = 22;
    starPath(5, o.radius, o.radius * .45);
    const g = ctx.createRadialGradient(0, -5, 2, 0, 0, o.radius);
    g.addColorStop(0, "#ffffff"); g.addColorStop(.32, color); g.addColorStop(1, "#6e77ff");
    ctx.fillStyle = g; ctx.fill();
    ctx.restore();
  }

  function drawGust(o) {
    ctx.save(); ctx.translate(o.x, o.y); ctx.rotate(o.angle * .2);
    ctx.shadowColor = "rgba(255,90,118,.65)"; ctx.shadowBlur = 20;
    const g = ctx.createLinearGradient(-28, -20, 28, 20);
    g.addColorStop(0, "#ff5578"); g.addColorStop(1, "#912b76");
    ctx.strokeStyle = g; ctx.lineWidth = 7; ctx.lineCap = "round";
    for (let i = -1; i <= 1; i++) {
      ctx.beginPath();
      ctx.moveTo(-26, i * 10);
      ctx.bezierCurveTo(-8, i * 10 - 16, 8, i * 10 + 16, 26, i * 10);
      ctx.stroke();
    }
    ctx.restore();
  }

  function drawPower(o) {
    const color = o.type === "shield" ? "#aa83ff" : "#7df2c4";
    ctx.save(); ctx.translate(o.x, o.y); ctx.rotate(o.angle);
    ctx.shadowColor = color; ctx.shadowBlur = 20;
    ctx.fillStyle = color; ctx.strokeStyle = "#fff"; ctx.lineWidth = 2;
    if (o.type === "shield") {
      ctx.beginPath(); ctx.moveTo(0, -18); ctx.lineTo(16, -10); ctx.lineTo(13, 9); ctx.quadraticCurveTo(0, 23, -13, 9); ctx.lineTo(-16, -10); ctx.closePath(); ctx.fill(); ctx.stroke();
    } else {
      ctx.beginPath(); ctx.arc(0, 0, 16, 0, TAU); ctx.fill(); ctx.stroke();
      ctx.strokeStyle = "#163c3b"; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, -9); ctx.moveTo(0, 0); ctx.lineTo(8, 4); ctx.stroke();
    }
    ctx.restore();
  }

  function drawHat() {
    ctx.save();
    const blink = player.invuln > 0 && Math.floor(player.invuln * 12) % 2 === 0;
    ctx.globalAlpha = blink ? .35 : 1;
    ctx.translate(player.x, player.y);
    ctx.rotate(Math.max(-.35, Math.min(.35, player.vx / 620)));
    if (player.dashTimer > 0) {
      ctx.globalAlpha *= .5;
      for (let i = 1; i <= 4; i++) {
        ctx.save(); ctx.translate(-player.vx * .012 * i, i * 5); ctx.scale(1 - i * .08, 1 - i * .08); drawHatShape(.22); ctx.restore();
      }
      ctx.globalAlpha = blink ? .35 : 1;
    }
    if (player.shield > 0) {
      ctx.strokeStyle = "rgba(170,131,255,.82)"; ctx.lineWidth = 4;
      ctx.shadowColor = "#aa83ff"; ctx.shadowBlur = 20;
      ctx.beginPath(); ctx.arc(0, 0, 42 + Math.sin(state.time * 6) * 2, 0, TAU); ctx.stroke();
      ctx.shadowBlur = 0;
    }
    ctx.rotate(player.angle);
    drawHatShape(1);
    ctx.restore();
  }

  function drawHatShape(alpha = 1) {
    ctx.globalAlpha *= alpha;
    ctx.shadowColor = "rgba(113,232,255,.65)"; ctx.shadowBlur = 22;
    const brim = ctx.createLinearGradient(-34, 0, 34, 0);
    brim.addColorStop(0, "#090b17"); brim.addColorStop(.48, "#33385e"); brim.addColorStop(1, "#0c0f21");
    ctx.fillStyle = brim;
    ctx.beginPath(); ctx.ellipse(0, 12, 36, 11, 0, 0, TAU); ctx.fill();
    const crown = ctx.createLinearGradient(-22, -30, 22, 16);
    crown.addColorStop(0, "#444b7d"); crown.addColorStop(.35, "#15182e"); crown.addColorStop(1, "#070914");
    ctx.fillStyle = crown;
    roundedRect(-21, -27, 42, 40, 8); ctx.fill();
    ctx.shadowBlur = 0;
    ctx.fillStyle = "#ffd166"; roundedRect(-21, 0, 42, 7, 2); ctx.fill();
    ctx.fillStyle = "rgba(255,255,255,.32)"; roundedRect(-14, -21, 7, 18, 3); ctx.fill();
  }

  function drawHudCanvas() {
    ctx.save();
    ctx.fillStyle = "rgba(7,10,23,.58)";
    roundedRect(22, 20, 182, 44, 14); ctx.fill();
    ctx.font = "800 15px system-ui"; ctx.textBaseline = "middle";
    ctx.fillStyle = "#b9bfd7"; ctx.fillText(`SHIFT ${state.level}`, 38, 42);
    for (let i = 0; i < 3; i++) {
      ctx.globalAlpha = i < state.lives ? 1 : .16;
      ctx.fillStyle = "#ff6980";
      ctx.beginPath();
      const x = 129 + i * 23, y = 42;
      ctx.moveTo(x, y + 8); ctx.bezierCurveTo(x - 15, y - 1, x - 9, y - 13, x, y - 5); ctx.bezierCurveTo(x + 9, y - 13, x + 15, y - 1, x, y + 8); ctx.fill();
    }
    ctx.globalAlpha = 1;
    ctx.fillStyle = "rgba(7,10,23,.58)";
    roundedRect(W - 196, 20, 174, 44, 14); ctx.fill();
    ctx.fillStyle = "#b9bfd7"; ctx.fillText("DASH", W - 180, 42);
    ctx.fillStyle = "rgba(255,255,255,.12)"; roundedRect(W - 125, 34, 87, 16, 8); ctx.fill();
    const dg = ctx.createLinearGradient(W - 125, 0, W - 38, 0); dg.addColorStop(0, "#71e8ff"); dg.addColorStop(1, "#aa83ff");
    ctx.fillStyle = dg; roundedRect(W - 125, 34, 87 * player.dash, 16, 8); ctx.fill();
    ctx.restore();
  }

  function draw() {
    ctx.save();
    const sx = state.shake ? (random() - .5) * state.shake : 0;
    const sy = state.shake ? (random() - .5) * state.shake : 0;
    ctx.translate(sx, sy);
    drawBackground();
    for (const o of objects) {
      if (o.type === "ticket") drawTicket(o);
      else if (o.type === "star") drawStar(o);
      else if (o.type === "gust") drawGust(o);
      else drawPower(o);
    }
    for (const p of particles) {
      ctx.globalAlpha = Math.max(0, p.life / p.max);
      ctx.fillStyle = p.color;
      ctx.beginPath(); ctx.arc(p.x, p.y, p.size, 0, TAU); ctx.fill();
    }
    ctx.globalAlpha = 1;
    drawHat();
    drawHudCanvas();
    if (state.flash > 0) {
      ctx.globalAlpha = state.flash * 1.8;
      ctx.fillStyle = "#ff4667"; ctx.fillRect(-20, -20, W + 40, H + 40);
    }
    ctx.restore();
  }

  let last = performance.now();
  function frame(now) {
    const dt = Math.min(.034, Math.max(0, (now - last) / 1000));
    last = now;
    update(dt);
    draw();
    requestAnimationFrame(frame);
  }

  function setPointer(e) {
    const r = canvas.getBoundingClientRect();
    state.pointerX = (e.clientX - r.left) / r.width * W;
  }
  canvas.addEventListener("pointerdown", e => { initAudio(); setPointer(e); canvas.setPointerCapture?.(e.pointerId); });
  canvas.addEventListener("pointermove", e => { if (e.buttons || e.pointerType === "touch") setPointer(e); });
  canvas.addEventListener("pointerup", () => { state.pointerX = null; });
  canvas.addEventListener("dblclick", dash);

  addEventListener("keydown", e => {
    if (["ArrowLeft", "ArrowRight", "Space"].includes(e.code)) e.preventDefault();
    if (e.code === "ArrowLeft" || e.code === "KeyA") keys.left = true;
    if (e.code === "ArrowRight" || e.code === "KeyD") keys.right = true;
    if (e.code === "Space") dash();
    if (e.code === "KeyP" || e.code === "Escape") pause();
    if ((e.code === "Enter" || e.code === "Space") && ["menu", "gameover"].includes(state.mode)) reset();
  });
  addEventListener("keyup", e => {
    if (e.code === "ArrowLeft" || e.code === "KeyA") keys.left = false;
    if (e.code === "ArrowRight" || e.code === "KeyD") keys.right = false;
  });
  addEventListener("blur", () => { keys.left = keys.right = false; if (state.mode === "running") pause(); });

  function bindHold(id, key) {
    const button = document.getElementById(id);
    const on = e => { e.preventDefault(); initAudio(); keys[key] = true; };
    const off = e => { e.preventDefault(); keys[key] = false; };
    button.addEventListener("pointerdown", on);
    button.addEventListener("pointerup", off);
    button.addEventListener("pointercancel", off);
    button.addEventListener("pointerleave", off);
  }
  bindHold("left", "left");
  bindHold("right", "right");
  document.getElementById("dash").addEventListener("pointerdown", e => { e.preventDefault(); initAudio(); dash(); });
  primary.addEventListener("click", () => state.mode === "paused" ? pause() : reset());

  requestAnimationFrame(frame);

  if (preview) {
    reset();
    state.score = 1260;
    state.combo = 6;
    state.time = 42;
    state.level = 3;
    player.shield = 1;
    player.dash = .82;
    objects.push(
      { type: "ticket", x: 255, y: 165, vx: 5, vy: 70, radius: 18, angle: -.2, spin: 1, phase: 1, value: 25 },
      { type: "star", x: 485, y: 115, vx: -5, vy: 70, radius: 17, angle: .4, spin: 2, phase: 2, value: 80 },
      { type: "gust", x: 710, y: 210, vx: -12, vy: 75, radius: 27, angle: .2, spin: -1, phase: 3, value: 0 },
      { type: "shield", x: 840, y: 120, vx: 0, vy: 60, radius: 15, angle: 0, spin: 1, phase: 4, value: 0 }
    );
    setTimeout(() => { state.mode = "paused"; }, 350);
  }
})();
