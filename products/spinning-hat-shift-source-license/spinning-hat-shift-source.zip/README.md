# Spinning Hat Shift — source package

A dependency-free HTML5 arcade game. Open `index.html` locally or upload the folder as an HTML5 project.

## Controls

- Left / Right arrows or A / D: move
- Space: dash
- P or Escape: pause
- Pointer and touch controls are included

## Technical notes

- No external assets, tracking, fonts, or network calls
- Canvas resolution: 960×540; responsive CSS scales to desktop and mobile
- Web Audio is generated locally after user interaction
- Best score is stored in `localStorage`
- `?preview=1` opens a deterministic paused preview state for marketing capture

## License

Copyright © 2026 Evan Brown / Cognilode. Commercial and redistribution rights are reserved. Purchasers may modify the source for personal use. Redistribution or resale of the source or substantially identical builds requires separate written permission.
